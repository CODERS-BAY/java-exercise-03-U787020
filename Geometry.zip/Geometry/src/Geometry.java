import java.util.Scanner;

public class Geometry {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int shape;

        System.out.println("Please select one of the following figures:");
        System.out.println("1 - Rectangle");
        System.out.println("2 - Square");
        System.out.println("3 - Perimeter rectangle");
        System.out.println("4 - Perimeter square");
        System.out.println("5 - Zone of a sphere");
        System.out.println("6 - Sphere with cylinder");
        System.out.println("7 - Ungula");
        shape = input.nextInt();

        if(shape == 1) {
            double l, w;
            System.out.print("Please enter length of the rectangle: ");
            l = input.nextDouble();
            System.out.print("Please enter width of the rectangle: ");
            w = input.nextDouble();
            double area = rectangleArea(l, w);
            System.out.println("Area = " + area);
        }

        if(shape == 2) {
            double l;
            System.out.print("Please enter lenth of the square: ");
            l = input.nextDouble();
            double area = squareArea(l);
            System.out.println("Area = " + area);
        }

        if(shape == 3) {
            double l, w;
            System.out.print("Please enter length of the rectangle: ");
            l = input.nextDouble();
            System.out.print("Please enter width of the rectangle: ");
            w = input.nextDouble();
            double perimeter = rectanglePerimeter(l, w);
            System.out.println("Perimeter = " + perimeter);
        }

        if(shape == 4) {
            double l;
            System.out.print("Please enter length of the square: ");
            l = input.nextDouble();
            double perimeter = squarePerimeter(l);
            System.out.println("Perimeter = " + perimeter);
        }

        if(shape == 5) {
            double h, r, x;
            System.out.print("Please enter height of the zone: ");
            h = input.nextDouble();
            System.out.print("Please enter radius 1 of the zone: ");
            r = input.nextDouble();
            System.out.print("Please enter radius 2 of the zone: ");
            x = input.nextDouble();
            double volume = zoneOfASphere(h, r, x);
            System.out.println("Volume = " + volume);
        }

        if(shape == 6) {
            double h;
            System.out.print("Please enter height of sphere: ");
            h = input.nextDouble();
            double volume = sphereWithCylinder(h);
            System.out.println("Volume = " + volume);
        }

        if(shape == 7) {
            double r, h;
            System.out.print("Please enter radius of Ungula: ");
            r = input.nextDouble();
            System.out.print("Please enter height of Ungula: ");
            h = input.nextDouble();
            double volume = ungula(r, h);
            System.out.println("Volume = " + volume);
        }
    }

    //area rectangle
    public static double rectangleArea(double width, double length) {
        double area = length * width;
        return area;
    }
    //area square
    public static double squareArea(double length) {
        double area = length * length;
        return area;
    }
    //perimeter rectangle
    public static double rectanglePerimeter(double width, double length) {
        double perimeter = (2 * length) + (2 * width);
        return perimeter;
    }
    //perimeter square
    public static double squarePerimeter(double length) {
        double perimeter = 4 * length;
        return perimeter;
    }
    //zone of a sphere
    public static double zoneOfASphere(double h, double r, double x) {
        double volume = (Math.PI * h * (3 * Math.pow(r,2) + 3 * Math.pow(x,2) + Math.pow(h,2)))/6;
        return volume;
    }
    //sphere with cylinder
    public static double sphereWithCylinder(double h) {
        double volume = (Math.PI * Math.pow(h,3))/6;
        return volume;
    }
    //Ungula
    public static double ungula(double r, double h) {
        double volume = (2 * Math.pow(r,2) * h)/3;
        return volume;
    }
}
